#!/bin/sh

SCRIPTPATH=$(cd "$(dirname "$0")"; pwd)
"$SCRIPTPATH/prancer-authn-sample-app" -importPath prancer-io/prancer-authn-sample-app -srcPath "$SCRIPTPATH/src" -runMode dev
